package com.chronos.tasktracker.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val dueDate: String,
    val dueTime: String,
    val priority: String = "medium",
    val reminderMinutesBefore: Int = 5,
    val isCompleted: Boolean = false
)
