package com.chronos.tasktracker.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.chronos.tasktracker.data.AppDatabase
import com.chronos.tasktracker.scheduler.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val tasks = AppDatabase.getInstance(context).taskDao().getPendingTasks()
                val scheduler = AlarmScheduler(context)
                tasks.forEach(scheduler::scheduleTaskReminder)
            } finally {
                pending.finish()
            }
        }
    }
}
