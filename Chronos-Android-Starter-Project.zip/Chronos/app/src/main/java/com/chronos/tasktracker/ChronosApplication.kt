package com.chronos.tasktracker

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class ChronosApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                REMINDER_CHANNEL_ID, "Task reminders", NotificationManager.IMPORTANCE_HIGH
            ).apply { description = "Scheduled reminders for Chronos tasks" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }
    companion object { const val REMINDER_CHANNEL_ID = "chronos_task_reminders" }
}
