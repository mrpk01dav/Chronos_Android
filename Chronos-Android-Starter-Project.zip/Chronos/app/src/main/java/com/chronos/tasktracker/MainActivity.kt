package com.chronos.tasktracker

import android.Manifest
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.chronos.tasktracker.data.AppDatabase
import com.chronos.tasktracker.data.model.TaskEntity
import com.chronos.tasktracker.scheduler.AlarmScheduler
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

private val ChronosBg = Color(0xFF0B0C11)
private val ChronosCard = Color(0xFF171923)
private val ChronosAccent = Color(0xFF8B7CFF)

class MainActivity : ComponentActivity() {
    private val requestNotifications = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = ChronosBg, surface = ChronosCard, primary = ChronosAccent
            )) {
                ChronosScreen()
            }
        }
    }
}

@Composable
private fun ChronosScreen() {
    val context = LocalContext.current
    val db = remember { AppDatabase.getInstance(context) }
    val scope = rememberCoroutineScope()
    val scheduler = remember { AlarmScheduler(context) }
    var tasks by remember { mutableStateOf<List<TaskEntity>>(emptyList()) }
    var title by remember { mutableStateOf("") }
    var dueDate by remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())) }
    var dueTime by remember { mutableStateOf("09:00") }
    var reminder by remember { mutableIntStateOf(5) }

    LaunchedEffect(Unit) { db.taskDao().observeTasks().collectLatest { tasks = it } }

    Surface(modifier = Modifier.fillMaxSize(), color = ChronosBg) {
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("CHRONOS", style = MaterialTheme.typography.labelLarge, color = ChronosAccent)
            Text("Your tasks, under control.", style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold, color = Color.White)
            Spacer(Modifier.height(18.dp))
            Card(colors = CardDefaults.cardColors(containerColor = ChronosCard),
                shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    OutlinedTextField(value = title, onValueChange = { title = it },
                        label = { Text("Task name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = {
                            val c = Calendar.getInstance()
                            DatePickerDialog(context, { _, y, m, d ->
                                dueDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, d)
                            }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                        }, modifier = Modifier.weight(1f)) { Text(dueDate) }
                        OutlinedButton(onClick = {
                            val c = Calendar.getInstance()
                            TimePickerDialog(context, { _, h, m ->
                                dueTime = String.format(Locale.US, "%02d:%02d", h, m)
                            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true).show()
                        }, modifier = Modifier.weight(1f)) { Text(dueTime) }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Reminder before due time: $reminder minutes", color = Color.LightGray)
                    Slider(value = reminder.toFloat(), onValueChange = { reminder = it.toInt() },
                        valueRange = 0f..60f, steps = 11)
                    Button(onClick = {
                        val clean = title.trim()
                        if (clean.isNotEmpty()) {
                            val task = TaskEntity(UUID.randomUUID().toString(), clean, dueDate, dueTime,
                                reminderMinutesBefore = reminder)
                            scope.launch {
                                db.taskDao().upsert(task)
                                scheduler.scheduleTaskReminder(task)
                                title = ""
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("＋ Add task & reminder") }
                }
            }
            Spacer(Modifier.height(18.dp))
            Text("YOUR TASKS · ${tasks.count { !it.isCompleted }} pending", color = Color.White,
                style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(tasks, key = { it.id }) { task ->
                    Card(colors = CardDefaults.cardColors(containerColor = ChronosCard),
                        shape = RoundedCornerShape(16.dp)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Column(Modifier.weight(1f)) {
                                Text(task.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("${task.dueDate} · ${task.dueTime}", color = Color.LightGray,
                                    style = MaterialTheme.typography.bodySmall)
                                if (task.isCompleted) Text("Completed", color = ChronosAccent)
                            }
                            if (!task.isCompleted) {
                                TextButton(onClick = {
                                    scope.launch {
                                        db.taskDao().markTaskComplete(task.id)
                                        scheduler.cancelTaskReminder(task)
                                    }
                                }) { Text("Done") }
                            }
                            TextButton(onClick = {
                                scope.launch {
                                    scheduler.cancelTaskReminder(task)
                                    db.taskDao().deleteTask(task.id)
                                }
                            }) { Text("Delete") }
                        }
                    }
                }
            }
        }
    }
}
