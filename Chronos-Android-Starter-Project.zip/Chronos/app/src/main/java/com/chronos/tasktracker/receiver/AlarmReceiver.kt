package com.chronos.tasktracker.receiver

import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.chronos.tasktracker.ChronosApplication
import com.chronos.tasktracker.MainActivity
import com.chronos.tasktracker.data.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class AlarmReceiver : BroadcastReceiver() {
    companion object {
        const val ACTION_TASK_REMINDER = "com.chronos.ACTION_TASK_REMINDER"
        const val ACTION_TASK_COMPLETE = "com.chronos.ACTION_TASK_COMPLETE"
        const val ACTION_TASK_SNOOZE = "com.chronos.ACTION_TASK_SNOOZE"
        const val EXTRA_TASK_ID = "EXTRA_TASK_ID"
        const val EXTRA_TASK_TITLE = "EXTRA_TASK_TITLE"
        const val EXTRA_TASK_PRIORITY = "EXTRA_TASK_PRIORITY"
        const val EXTRA_TASK_DUE_TIME = "EXTRA_TASK_DUE_TIME"
        const val EXTRA_SNOOZE_MINUTES = "EXTRA_SNOOZE_MINUTES"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val taskId = intent.getStringExtra(EXTRA_TASK_ID) ?: return
        when (intent.action) {
            ACTION_TASK_REMINDER -> showNotification(
                context, taskId,
                intent.getStringExtra(EXTRA_TASK_TITLE) ?: "Task reminder",
                intent.getStringExtra(EXTRA_TASK_PRIORITY) ?: "medium",
                intent.getStringExtra(EXTRA_TASK_DUE_TIME) ?: ""
            )
            ACTION_TASK_COMPLETE -> {
                context.getSystemService(NotificationManager::class.java).cancel(taskId.hashCode())
                CoroutineScope(Dispatchers.IO).launch {
                    AppDatabase.getInstance(context).taskDao().markTaskComplete(taskId)
                }
            }
            ACTION_TASK_SNOOZE -> {
                context.getSystemService(NotificationManager::class.java).cancel(taskId.hashCode())
                val mins = intent.getIntExtra(EXTRA_SNOOZE_MINUTES, 10).coerceIn(1, 240)
                val title = intent.getStringExtra(EXTRA_TASK_TITLE) ?: "Task reminder"
                val next = Intent(context, AlarmReceiver::class.java).apply {
                    action = ACTION_TASK_REMINDER
                    putExtra(EXTRA_TASK_ID, taskId)
                    putExtra(EXTRA_TASK_TITLE, title)
                    putExtra(EXTRA_TASK_PRIORITY, intent.getStringExtra(EXTRA_TASK_PRIORITY) ?: "medium")
                    putExtra(EXTRA_TASK_DUE_TIME, intent.getStringExtra(EXTRA_TASK_DUE_TIME) ?: "")
                }
                val pi = PendingIntent.getBroadcast(context, taskId.hashCode(), next,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val at = System.currentTimeMillis() + mins * 60_000L
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                } else {
                    am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                }
            }
        }
    }

    private fun showNotification(context: Context, taskId: String, title: String, priority: String, dueTime: String) {
        val openIntent = Intent(context, MainActivity::class.java).apply {
            putExtra("OPEN_TASK_ID", taskId)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPi = PendingIntent.getActivity(context, taskId.hashCode(), openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        fun actionPi(action: String, requestCode: Int, snooze: Boolean = false) =
            PendingIntent.getBroadcast(context, requestCode, Intent(context, AlarmReceiver::class.java).apply {
                this.action = action
                putExtra(EXTRA_TASK_ID, taskId)
                putExtra(EXTRA_TASK_TITLE, title)
                putExtra(EXTRA_TASK_PRIORITY, priority)
                putExtra(EXTRA_TASK_DUE_TIME, dueTime)
                if (snooze) putExtra(EXTRA_SNOOZE_MINUTES, 10)
            }, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val notification = NotificationCompat.Builder(context, ChronosApplication.REMINDER_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle(title)
            .setContentText("Priority: ${priority.uppercase()} · Due ${dueTime.ifBlank { "today" }}")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setAutoCancel(true)
            .setContentIntent(openPi)
            .addAction(android.R.drawable.checkbox_on_background, "Complete",
                actionPi(ACTION_TASK_COMPLETE, (taskId + "_complete").hashCode()))
            .addAction(android.R.drawable.ic_menu_recent_history, "Snooze 10m",
                actionPi(ACTION_TASK_SNOOZE, (taskId + "_snooze").hashCode(), true))
            .setVibrate(longArrayOf(0, 250, 150, 250))
            .build()
        context.getSystemService(NotificationManager::class.java).notify(taskId.hashCode(), notification)
    }
}
