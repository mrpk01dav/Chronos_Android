# Chronos Android starter project

This is a starter native Android project based on the Kotlin snippets shared in the conversation. It includes a minimal dark-mode task list, Room persistence, alarm scheduling, notification actions, and boot-time alarm restoration.

## Build
1. Install Android Studio (current stable version) on a computer.
2. Open Android Studio and choose **Open**, then select this `Chronos` folder.
3. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Click **Run** to build and install a debug version.
6. To create an APK, choose **Build > Build APK(s)**. The debug APK is normally under `app/build/outputs/apk/debug/`.

## Important limitations
- This is a functional starter project, not a complete reproduction of every feature from the original web app.
- Daily/weekly/monthly/yearly recurring task generation, report charts, task categories, editing, and backup/export are not implemented in this starter.
- Reminders are local Android alarms. Android permissions, notification settings, exact-alarm access, and device-specific battery policies can affect delivery.
- Test reminders on your own device before relying on them for important deadlines.
- This archive does not include a prebuilt APK or Gradle wrapper JAR. Android Studio can configure/build the project after opening it and installing the required tools.
